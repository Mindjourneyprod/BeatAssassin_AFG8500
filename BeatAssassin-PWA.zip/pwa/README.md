# BeatAssassin AFG8500 — PWA Deployment Guide

## What's In This Package

```
beatassassin-pwa/
├── dist/                  ← Ready-to-deploy build (just upload this folder)
│   ├── index.html
│   ├── manifest.json
│   ├── sw.js
│   ├── icons/
│   └── assets/
├── src/                   ← Source code (if you want to modify & rebuild)
│   ├── App.jsx
│   └── main.jsx
├── public/
│   ├── manifest.json
│   ├── sw.js
│   └── icons/
├── index.html
├── package.json
├── vite.config.js
└── README.md              ← You are here
```

---

## Option A: Deploy to Vercel (Easiest — Free)

### 1. Create a GitHub repo
- Go to https://github.com/new
- Create a new repository (e.g., "beatassassin")
- Upload the **entire `beatassassin-pwa` folder** contents to the repo

### 2. Connect to Vercel
- Go to https://vercel.com and sign in with GitHub
- Click **"New Project"**
- Import your `beatassassin` repository
- Vercel auto-detects Vite — just click **Deploy**
- Wait ~30 seconds. You get a live URL like `beatassassin.vercel.app`

### 3. Add to iPhone Home Screen
- Open Safari on your iPhone
- Go to your Vercel URL (e.g., `https://beatassassin.vercel.app`)
- Tap the **Share button** (square with arrow)
- Scroll down and tap **"Add to Home Screen"**
- Name it "BeatAssassin" and tap **Add**
- The app icon appears on your home screen!

It now launches fullscreen with no browser UI, works offline, and feels like a native app.

---

## Option B: Deploy to Netlify (Also Free)

### 1. Drag & drop deploy
- Go to https://app.netlify.com/drop
- Drag the **`dist`** folder onto the page
- Done! You get a URL instantly.

### 2. Add to iPhone
- Same steps as above — open in Safari, Share → Add to Home Screen

---

## Option C: Deploy to GitHub Pages (Free)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "BeatAssassin PWA"
git remote add origin https://github.com/YOUR_USERNAME/beatassassin.git
git push -u origin main
```

### 2. Enable Pages
- Go to repo Settings → Pages
- Source: "GitHub Actions"
- Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install && npm run build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

### 3. Add to iPhone
- Open `https://YOUR_USERNAME.github.io/beatassassin` in Safari
- Share → Add to Home Screen

---

## Option D: Self-Host (Any Web Server)

Just upload the contents of the **`dist/`** folder to any web server. The only requirement is HTTPS (needed for service workers).

```bash
# Example with a simple server for testing:
cd dist
npx serve .
```

---

## Rebuilding After Changes

If you modify the source code:

```bash
# Install dependencies (first time only)
npm install

# Development server with hot reload
npm run dev

# Build for production
npm run build
```

The built files go into `dist/`. Upload that folder to deploy.

---

## Troubleshooting

**App doesn't install / no "Add to Home Screen":**
- Must be served over HTTPS (localhost is exempt for testing)
- Must be opened in Safari (Chrome on iOS doesn't support PWA install)

**No sound on first tap:**
- iOS requires a user gesture to start audio. The first pad tap initializes the audio engine — this is normal.

**App doesn't work offline:**
- Visit the app once while online to cache all assets
- The service worker caches everything on first load

**Updating the app:**
- After redeploying, open the app and wait a few seconds — the service worker auto-updates
- Or force-refresh: close the app completely and reopen it

---

## Technical Details

- **Framework:** React 18 + Vite 5
- **Audio:** Web Audio API (no external samples — all synthesized)
- **Bundle size:** ~57KB gzipped
- **Offline:** Service worker with cache-first strategy
- **Compatibility:** iOS Safari 15+, Chrome 90+, Firefox 90+
