import { useState, useRef, useCallback, useEffect, useMemo } from "react";

/* ═══════════════════════════════════════════
   AUDIO ENGINE — with velocity + per-pad params
   ═══════════════════════════════════════════ */
class DrumEngine {
  constructor() { this.ctx = null; this.initialized = false; }
  init() {
    if (this.initialized) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.8;
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -12;
    this.compressor.knee.value = 6;
    this.compressor.ratio.value = 4;
    this.masterGain.connect(this.compressor);
    this.compressor.connect(this.ctx.destination);
    this.initialized = true;
  }
  resume() { if (this.ctx?.state === "suspended") this.ctx.resume(); }
  _nb(d) {
    const l = this.ctx.sampleRate * d, b = this.ctx.createBuffer(1, l, this.ctx.sampleRate), a = b.getChannelData(0);
    for (let i = 0; i < l; i++) a[i] = Math.random() * 2 - 1; return b;
  }
  _pan(val) {
    const p = this.ctx.createStereoPanner();
    p.pan.value = Math.max(-1, Math.min(1, val / 50));
    p.connect(this.masterGain); return p;
  }
  _pitch(s) { return Math.pow(2, s / 12); }
  _dec(d) { return 0.2 + (d / 100) * 1.8; }

  /* Metronome click */
  metroClick(t, accent) {
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sine"; o.frequency.value = accent ? 1200 : 800;
    g.gain.setValueAtTime(accent ? 0.15 : 0.08, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.03);
    o.connect(g); g.connect(this.masterGain);
    o.start(t); o.stop(t + 0.04);
  }

  kick(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 60);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(160 * pi, t); o.frequency.exponentialRampToValueAtTime(30 * pi, t + 0.15);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.4 * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.4 * dc + 0.01);
    const c = this.ctx.createOscillator(), cg = this.ctx.createGain();
    c.type = "square"; c.frequency.setValueAtTime(800 * pi, t); c.frequency.exponentialRampToValueAtTime(100, t + 0.02);
    cg.gain.setValueAtTime(0.3 * v, t); cg.gain.exponentialRampToValueAtTime(0.001, t + 0.03);
    c.connect(cg); cg.connect(pan); c.start(t); c.stop(t + 0.05);
  }
  snare(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 50);
    const o = this.ctx.createOscillator(), og = this.ctx.createGain();
    o.type = "triangle"; o.frequency.setValueAtTime(200 * pi, t); o.frequency.exponentialRampToValueAtTime(120 * pi, t + 0.05);
    og.gain.setValueAtTime(0.7 * v, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.12 * dc);
    o.connect(og); og.connect(pan); o.start(t); o.stop(t + 0.15 * dc + 0.01);
    const n = this.ctx.createBufferSource(), ng = this.ctx.createGain(), hp = this.ctx.createBiquadFilter();
    n.buffer = this._nb(0.2 * dc); hp.type = "highpass"; hp.frequency.value = 3000;
    ng.gain.setValueAtTime(0.6 * v, t); ng.gain.exponentialRampToValueAtTime(0.001, t + 0.18 * dc);
    n.connect(hp); hp.connect(ng); ng.connect(pan); n.start(t); n.stop(t + 0.2 * dc + 0.01);
  }
  closedHat(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), dc = this._dec(p?.decay ?? 30);
    const n = this.ctx.createBufferSource(), hp = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    n.buffer = this._nb(0.08 * dc); hp.type = "highpass"; hp.frequency.value = 7000 * this._pitch(p?.tune ?? 0);
    g.gain.setValueAtTime(0.35 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.06 * dc);
    n.connect(hp); hp.connect(g); g.connect(pan); n.start(t); n.stop(t + 0.08 * dc + 0.01);
  }
  openHat(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), dc = this._dec(p?.decay ?? 60);
    const n = this.ctx.createBufferSource(), hp = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    n.buffer = this._nb(0.4 * dc); hp.type = "highpass"; hp.frequency.value = 6000 * this._pitch(p?.tune ?? 0);
    g.gain.setValueAtTime(0.35 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.35 * dc);
    n.connect(hp); hp.connect(g); g.connect(pan); n.start(t); n.stop(t + 0.4 * dc + 0.01);
  }
  clap(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 50);
    for (let i = 0; i < 3; i++) {
      const n = this.ctx.createBufferSource(), bp = this.ctx.createBiquadFilter(), g = this.ctx.createGain(), off = i * 0.012;
      n.buffer = this._nb(0.03); bp.type = "bandpass"; bp.frequency.value = 2500 * pi; bp.Q.value = 1.5;
      g.gain.setValueAtTime(0, t + off); g.gain.linearRampToValueAtTime(0.6 * v, t + off + 0.005);
      g.gain.exponentialRampToValueAtTime(0.001, t + off + 0.03);
      n.connect(bp); bp.connect(g); g.connect(pan); n.start(t + off); n.stop(t + off + 0.04);
    }
    const tl = this.ctx.createBufferSource(), bp = this.ctx.createBiquadFilter(), tg = this.ctx.createGain();
    tl.buffer = this._nb(0.25 * dc); bp.type = "bandpass"; bp.frequency.value = 2500 * pi; bp.Q.value = 0.8;
    tg.gain.setValueAtTime(0.5 * v, t + 0.036); tg.gain.exponentialRampToValueAtTime(0.001, t + 0.2 * dc);
    tl.connect(bp); bp.connect(tg); tg.connect(pan); tl.start(t + 0.036); tl.stop(t + 0.25 * dc + 0.01);
  }
  _tom(f1, f2, fd, gd, bv, t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 60);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(f1 * pi, t); o.frequency.exponentialRampToValueAtTime(f2 * pi, t + fd * dc);
    g.gain.setValueAtTime(bv * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + gd * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + gd * dc + 0.05);
  }
  tomLow(t, p, v) { this._tom(120, 60, 0.2, 0.3, 0.8, t, p, v); }
  tomMid(t, p, v) { this._tom(200, 100, 0.15, 0.25, 0.7, t, p, v); }
  tomHigh(t, p, v) { this._tom(300, 150, 0.1, 0.2, 0.6, t, p, v); }
  rimshot(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 30);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "square"; o.frequency.setValueAtTime(800 * pi, t); o.frequency.exponentialRampToValueAtTime(400 * pi, t + 0.02);
    g.gain.setValueAtTime(0.5 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.06 * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.08 * dc + 0.01);
  }
  cowbell(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 50);
    [587, 845].forEach(f => {
      const o = this.ctx.createOscillator(), g = this.ctx.createGain(), bp = this.ctx.createBiquadFilter();
      o.type = "square"; o.frequency.value = f * pi; g.gain.setValueAtTime(0.3 * v, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.25 * dc); bp.type = "bandpass"; bp.frequency.value = 700; bp.Q.value = 3;
      o.connect(bp); bp.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.3 * dc + 0.01);
    });
  }
  ride(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), dc = this._dec(p?.decay ?? 70);
    const n = this.ctx.createBufferSource(), hp = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    n.buffer = this._nb(0.6 * dc); hp.type = "highpass"; hp.frequency.value = 8000 * this._pitch(p?.tune ?? 0);
    g.gain.setValueAtTime(0.2 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.5 * dc);
    n.connect(hp); hp.connect(g); g.connect(pan); n.start(t); n.stop(t + 0.6 * dc + 0.01);
  }
  crash(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), dc = this._dec(p?.decay ?? 80);
    const n = this.ctx.createBufferSource(), hp = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    n.buffer = this._nb(1.2 * dc); hp.type = "highpass"; hp.frequency.value = 4000 * this._pitch(p?.tune ?? 0);
    g.gain.setValueAtTime(0.4 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 1.0 * dc);
    n.connect(hp); hp.connect(g); g.connect(pan); n.start(t); n.stop(t + 1.2 * dc + 0.01);
  }
  shaker(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), dc = this._dec(p?.decay ?? 30);
    const n = this.ctx.createBufferSource(), bp = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    n.buffer = this._nb(0.1 * dc); bp.type = "bandpass"; bp.frequency.value = 9000 * this._pitch(p?.tune ?? 0); bp.Q.value = 2;
    g.gain.setValueAtTime(0.25 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.08 * dc);
    n.connect(bp); bp.connect(g); g.connect(pan); n.start(t); n.stop(t + 0.1 * dc + 0.01);
  }
  conga(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 50);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(350 * pi, t); o.frequency.exponentialRampToValueAtTime(200 * pi, t + 0.08);
    g.gain.setValueAtTime(0.7 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.2 * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.25 * dc + 0.01);
  }
  zap(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 50);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sawtooth"; o.frequency.setValueAtTime(1200 * pi, t); o.frequency.exponentialRampToValueAtTime(50, t + 0.15 * dc);
    g.gain.setValueAtTime(0.4 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.15 * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.2 * dc + 0.01);
  }
  subBass(t, p, vel = 1) {
    t = t || this.ctx.currentTime;
    const v = ((p?.volume ?? 80) / 100) * vel, pan = this._pan(p?.pan ?? 0), pi = this._pitch(p?.tune ?? 0), dc = this._dec(p?.decay ?? 70);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(55 * pi, t);
    g.gain.setValueAtTime(0.9 * v, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.5 * dc);
    o.connect(g); g.connect(pan); o.start(t); o.stop(t + 0.55 * dc + 0.01);
  }
  play(i, t, params, vel) {
    this.init(); this.resume();
    const fns = [
      (t,p,v)=>this.kick(t,p,v),(t,p,v)=>this.snare(t,p,v),(t,p,v)=>this.closedHat(t,p,v),(t,p,v)=>this.openHat(t,p,v),
      (t,p,v)=>this.clap(t,p,v),(t,p,v)=>this.tomLow(t,p,v),(t,p,v)=>this.tomMid(t,p,v),(t,p,v)=>this.tomHigh(t,p,v),
      (t,p,v)=>this.rimshot(t,p,v),(t,p,v)=>this.cowbell(t,p,v),(t,p,v)=>this.ride(t,p,v),(t,p,v)=>this.crash(t,p,v),
      (t,p,v)=>this.shaker(t,p,v),(t,p,v)=>this.conga(t,p,v),(t,p,v)=>this.zap(t,p,v),(t,p,v)=>this.subBass(t,p,v),
    ];
    fns[i]?.(t, params, vel ?? 1);
  }
}

/* ═══════════════════════════════════════════
   PROGRAMS
   ═══════════════════════════════════════════ */
const SOUND_NAMES = ["KICK","SNARE","CH HAT","OH HAT","CLAP","TOM LO","TOM MD","TOM HI","RIMSHOT","COWBELL","RIDE","CRASH","SHAKER","CONGA","ZAP FX","SUB BASS"];
const defaultPP = () => SOUND_NAMES.map(() => ({ volume: 80, pan: 0, tune: 0, decay: 50 }));
const PRESET_KITS = {
  A: { name: "STANDARD", params: defaultPP() },
  B: { name: "HEAVY", params: SOUND_NAMES.map((_, i) => ({
    volume: [100,90,70,75,85,95,90,85,60,70,65,80,55,80,90,100][i],
    pan: [0,-5,10,-10,5,20,-20,15,0,0,25,-25,30,-30,0,0][i],
    tune: [-2,-1,0,0,0,-5,-3,-1,2,0,0,-1,3,0,-7,-5][i],
    decay: [80,60,20,50,55,70,65,55,25,40,60,90,20,45,70,90][i],
  }))},
  C: { name: "TIGHT", params: SOUND_NAMES.map(() => ({ volume: 75, pan: 0, tune: 2, decay: 25 })) },
  D: { name: "WIDE", params: SOUND_NAMES.map((_, i) => ({ volume: 70, pan: Math.round((i % 2 === 0 ? -1 : 1) * (10 + i * 3)), tune: 0, decay: 80 })) },
};

/* ═══════════════════════════════════════════
   SEQUENCER
   ═══════════════════════════════════════════ */
const TOTAL_STEPS = 16;
class Sequencer {
  constructor(engine) {
    this.engine = engine; this.tempo = 120; this.playing = false;
    this.recording = false; this.overdub = false; this.currentStep = 0;
    this.bars = 2; this.totalSteps = TOTAL_STEPS * this.bars; this.quantize = "1/16";
    this.grid = Array.from({ length: 16 }, () => new Set());
    this.nextStepTime = 0; this.timerID = null; this.lookAhead = 0.05; this.scheduleInterval = 25;
    this.onStep = null; this.onStop = null; this.padParams = null;
    this.metronome = false; this.swing = 0;
  }
  get stepDuration() { return (60 / this.tempo) / 4; }
  setTempo(t) { this.tempo = Math.max(30, Math.min(300, t)); }
  setBars(b) {
    this.bars = Math.max(1, Math.min(8, b));
    const nt = TOTAL_STEPS * this.bars;
    if (nt !== this.totalSteps) { this.grid.forEach(s => { s.forEach(v => { if (v >= nt) s.delete(v); }); }); this.totalSteps = nt; }
  }
  start(fb = false) {
    this.engine.init(); this.engine.resume();
    if (fb) this.currentStep = 0;
    this.playing = true; this.nextStepTime = this.engine.ctx.currentTime + 0.05; this._schedule();
  }
  stop() {
    this.playing = false; this.recording = false; this.overdub = false;
    if (this.timerID) { clearTimeout(this.timerID); this.timerID = null; }
    this.currentStep = 0; this.onStop?.();
  }
  startRecord() { this.recording = true; this.overdub = false; this.grid = Array.from({ length: 16 }, () => new Set()); this.start(true); }
  startOverdub() { this.overdub = true; this.recording = true; if (!this.playing) this.start(false); }
  recordHit(si) {
    if (!this.recording && !this.overdub) return;
    let step = this.currentStep;
    if (this.quantize !== "OFF") { const g = this.quantize === "1/4" ? 4 : this.quantize === "1/8" ? 2 : 1; step = Math.round(step / g) * g; if (step >= this.totalSteps) step = 0; }
    this.grid[si].add(step);
  }
  toggleStep(si, step) { this.grid[si].has(step) ? this.grid[si].delete(step) : this.grid[si].add(step); }
  clearAll() { this.grid = Array.from({ length: 16 }, () => new Set()); }
  _schedule() {
    if (!this.playing) return;
    const ctx = this.engine.ctx;
    while (this.nextStepTime < ctx.currentTime + this.lookAhead) {
      // Swing: delay even 16th notes
      let swingOffset = 0;
      if (this.swing > 0 && this.currentStep % 2 === 1) {
        swingOffset = this.stepDuration * (this.swing / 100) * 0.5;
      }
      const playTime = this.nextStepTime + swingOffset;
      for (let s = 0; s < 16; s++) {
        if (this.grid[s].has(this.currentStep)) {
          this.engine.play(s, playTime, this.padParams?.[s], 1);
        }
      }
      // Metronome
      if (this.metronome) {
        const isBeat = this.currentStep % 4 === 0;
        const isDownbeat = this.currentStep % 16 === 0;
        if (isBeat) this.engine.metroClick(playTime, isDownbeat);
      }
      this.onStep?.(this.currentStep);
      this.nextStepTime += this.stepDuration;
      this.currentStep = (this.currentStep + 1) % this.totalSteps;
    }
    this.timerID = setTimeout(() => this._schedule(), this.scheduleInterval);
  }
}

/* ═══════════════════════════════════════════
   SCREENS
   ═══════════════════════════════════════════ */
const SCREENS = {
  MAIN: { title: "MAIN", fields: [
    { label: "Sequence", key: "seq", type: "number", min: 1, max: 99, pad: 2 },
    { label: "Track", key: "track", type: "number", min: 1, max: 64, pad: 2 },
    { label: "Tempo", key: "tempo", type: "decimal", min: 30, max: 300, step: 0.1 },
    { label: "Tsig", key: "tsig", type: "list", options: ["1/4","2/4","3/4","4/4","5/4","6/4","7/4","6/8"] },
  ], fKeys: ["SEQ","TR","PROG","SAMPLE","MIDI/SY","EFFECT"] },
  SEQ: { title: "SEQUENCER", isSequencer: true, fields: [
    { label: "Bars", key: "bars", type: "number", min: 1, max: 8, pad: 1 },
    { label: "Quantize", key: "quantize", type: "list", options: ["OFF","1/4","1/8","1/16"] },
    { label: "Swing", key: "swing", type: "number", min: 0, max: 75 },
    { label: "Metro", key: "metronome", type: "list", options: ["OFF","ON"] },
  ], fKeys: ["MAIN","CLEAR","BARS","QUANT","SWING","METRO"] },
  TRIM: { title: "TRIM", fields: [
    { label: "Sample", key: "trimSample", type: "text" },
    { label: "Start", key: "trimStart", type: "number", min: 0, max: 99999 },
    { label: "End", key: "trimEnd", type: "number", min: 0, max: 99999 },
    { label: "Loop", key: "trimLoop", type: "list", options: ["OFF","ON","ALOOP"] },
  ], fKeys: ["MAIN","PLAY","LOOP","EDIT","ZONE","PURGE"] },
  PROG: { title: "PROGRAM", isProgram: true, fields: [
    { label: "Volume", key: "p_volume", type: "number", min: 0, max: 100 },
    { label: "Pan", key: "p_pan", type: "number", min: -50, max: 50 },
    { label: "Tune", key: "p_tune", type: "number", min: -12, max: 12 },
    { label: "Decay", key: "p_decay", type: "number", min: 0, max: 100 },
  ], fKeys: ["MAIN","RESET","COPY","PASTE","INIT","SAVE"] },
  EFFECT: { title: "EFFECTS", fields: [
    { label: "Type", key: "fxType", type: "list", options: ["OFF","REVERB","DELAY","CHORUS","FLANGE","PHASER"] },
    { label: "Level", key: "fxLevel", type: "number", min: 0, max: 100 },
    { label: "Param1", key: "fxP1", type: "number", min: 0, max: 127 },
    { label: "Param2", key: "fxP2", type: "number", min: 0, max: 127 },
  ], fKeys: ["MAIN","TYPE","EDIT","SEND","MSTR","BYPASS"] },
  MIDI: { title: "MIDI/SYNC", fields: [
    { label: "MIDI Ch", key: "midiCh", type: "number", min: 1, max: 16, pad: 2 },
    { label: "Sync", key: "midiSync", type: "list", options: ["INT","EXT","MTC"] },
    { label: "Clock", key: "midiClock", type: "list", options: ["OFF","OUT","IN"] },
    { label: "SoftTh", key: "softThru", type: "list", options: ["OFF","A","B","A+B"] },
  ], fKeys: ["MAIN","CHAN","FILT","CTRL","SYNC","SOFT"] },
};
const SCREEN_ORDER = ["MAIN","SEQ","TRIM","PROG","EFFECT","MIDI"];
const DEFAULT_DATA = {
  seq: 1, track: 1, tempo: 120.0, tsig: "4/4", bars: 2, quantize: "1/16", loop: "ON",
  swing: 0, metronome: "OFF",
  trimSample: "Kick-01", trimStart: 0, trimEnd: 44100, trimLoop: "OFF",
  fxType: "OFF", fxLevel: 50, fxP1: 64, fxP2: 64,
  midiCh: 1, midiSync: "INT", midiClock: "OFF", softThru: "OFF",
  p_volume: 80, p_pan: 0, p_tune: 0, p_decay: 50,
};

const PAD_GLOW = ["#ff5533","#ff8822","#22ccee","#22ccee","#ee44aa","#ff7733","#ff7733","#ff7733","#ccaa22","#ffbb00","#66aaee","#ffffff","#88ee88","#cc7755","#9944ff","#ff3333"];
const PAD_LABELS = ["13","14","15","16","9","10","11","12","5","6","7","8","1","2","3","4"];
const GRID_TO_PAD = [12,13,14,15,8,9,10,11,4,5,6,7,0,1,2,3];

/* ═══════════════════════════════════════════
   BOOT SCREEN
   ═══════════════════════════════════════════ */
function BootScreen({ onComplete }) {
  const [phase, setPhase] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1200);
    const t3 = setTimeout(() => setPhase(3), 2000);
    const t4 = setTimeout(() => onComplete(), 2800);
    const pi = setInterval(() => setProgress(p => Math.min(100, p + 4)), 50);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); clearInterval(pi); };
  }, [onComplete]);

  return (
    <div style={{ ...BS.wrapper, opacity: phase >= 3 ? 0 : 1, transition: "opacity 0.6s" }}>
      <div style={BS.inner}>
        <div style={{ ...BS.logo, opacity: phase >= 1 ? 1 : 0, transform: phase >= 1 ? "translateY(0)" : "translateY(10px)", transition: "all 0.6s ease-out" }}>
          <span style={BS.logoText}>BeatAssassin</span>
          <span style={BS.logoSub}>AFG8500</span>
        </div>
        <div style={{ ...BS.progressWrap, opacity: phase >= 2 ? 1 : 0, transition: "opacity 0.4s" }}>
          <div style={BS.progressTrack}>
            <div style={{ ...BS.progressFill, width: `${progress}%` }} />
          </div>
          <span style={BS.progressText}>
            {progress < 30 ? "Initializing DSP..." : progress < 60 ? "Loading programs..." : progress < 90 ? "Calibrating pads..." : "Ready"}
          </span>
        </div>
        <span style={{ ...BS.version, opacity: phase >= 1 ? 0.4 : 0 }}>v2.1.0 · 16-Voice Synthesis Engine</span>
      </div>
    </div>
  );
}

const BS = {
  wrapper: {
    position: "absolute", inset: 0, zIndex: 100,
    background: "linear-gradient(180deg, #1c1810 0%, #2e1800 100%)",
    display: "flex", alignItems: "center", justifyContent: "center",
    borderRadius: 20,
  },
  inner: { display: "flex", flexDirection: "column", alignItems: "center", gap: 20, padding: 40 },
  logo: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4 },
  logoText: { fontFamily: "'Outfit', sans-serif", fontWeight: 900, fontSize: 32, color: "#ffa830", textShadow: "0 0 30px rgba(255,160,40,0.3)", letterSpacing: -1 },
  logoSub: { fontFamily: "'Outfit', sans-serif", fontWeight: 300, fontSize: 14, color: "#9a6830", letterSpacing: 8 },
  progressWrap: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8, width: 200 },
  progressTrack: { width: "100%", height: 3, background: "rgba(255,160,40,0.1)", borderRadius: 2, overflow: "hidden" },
  progressFill: { height: "100%", background: "linear-gradient(90deg, #ffa830, #ffcc60)", borderRadius: 2, transition: "width 0.1s" },
  progressText: { fontFamily: "'Share Tech Mono', monospace", fontSize: 9, color: "#7a5828" },
  version: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#7a5828", marginTop: 20 },
};

/* ═══════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════ */
export default function BeatAssassin() {
  const [booted, setBooted] = useState(false);
  const [activePads, setActivePads] = useState({});
  const [padVelocities, setPadVelocities] = useState({});
  const [activeBtn, setActiveBtn] = useState(null);
  const [lastPad, setLastPad] = useState(null);
  const [currentScreen, setCurrentScreen] = useState("MAIN");
  const [cursorRow, setCursorRow] = useState(0);
  const [data, setData] = useState({ ...DEFAULT_DATA });
  const [padBank, setPadBank] = useState("A");
  const [showPadHit, setShowPadHit] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isOverdub, setIsOverdub] = useState(false);
  const [currentStep, setCurrentStep] = useState(-1);
  const [gridVersion, setGridVersion] = useState(0);
  const [seqViewSound, setSeqViewSound] = useState(0);
  const [selectedPad, setSelectedPad] = useState(0);
  const [clipboard, setClipboard] = useState(null);
  const [programs, setPrograms] = useState(() => {
    const p = {};
    ["A","B","C","D"].forEach(k => {
      p[k] = { name: PRESET_KITS[k].name, params: JSON.parse(JSON.stringify(PRESET_KITS[k].params)), grid: Array.from({ length: 16 }, () => new Set()) };
    });
    return p;
  });

  const engineRef = useRef(null);
  const seqRef = useRef(null);
  const wheelStartY = useRef(0);
  const wheelStartVal = useRef(0);
  const padTouchTimes = useRef({});

  useEffect(() => {
    const eng = new DrumEngine();
    engineRef.current = eng;
    const seq = new Sequencer(eng);
    seq.onStep = (step) => setCurrentStep(step);
    seq.onStop = () => { setCurrentStep(-1); setIsPlaying(false); setIsRecording(false); setIsOverdub(false); };
    seqRef.current = seq;
    return () => { seq.stop(); eng.ctx?.close(); };
  }, []);

  useEffect(() => {
    if (!seqRef.current) return;
    seqRef.current.setTempo(data.tempo);
    seqRef.current.setBars(data.bars);
    seqRef.current.quantize = data.quantize;
    seqRef.current.swing = data.swing;
    seqRef.current.metronome = data.metronome === "ON";
  }, [data.tempo, data.bars, data.quantize, data.swing, data.metronome]);

  useEffect(() => {
    if (!seqRef.current) return;
    seqRef.current.padParams = programs[padBank].params;
    seqRef.current.grid = programs[padBank].grid;
  }, [padBank, programs]);

  useEffect(() => {
    const pp = programs[padBank].params[selectedPad];
    if (pp) setData(d => ({ ...d, p_volume: pp.volume, p_pan: pp.pan, p_tune: pp.tune, p_decay: pp.decay }));
  }, [selectedPad, padBank, programs]);

  /* ── Velocity: measure time between pointerdown events or use touch force ── */
  const getVelocity = useCallback((e, gridIdx) => {
    const now = performance.now();
    const last = padTouchTimes.current[gridIdx] || 0;
    padTouchTimes.current[gridIdx] = now;
    // Try touch force API
    if (e.nativeEvent?.touches?.[0]?.force > 0) {
      return Math.max(0.3, Math.min(1, e.nativeEvent.touches[0].force * 1.5));
    }
    // Fallback: rapid re-hits = softer (ghost notes), slow = full velocity
    const gap = now - last;
    if (gap < 80) return 0.4;
    if (gap < 150) return 0.65;
    return 0.85 + Math.random() * 0.15; // slight humanize
  }, []);

  /* ── Haptic patterns ── */
  const haptic = useCallback((type) => {
    if (!navigator.vibrate) return;
    if (type === "pad") navigator.vibrate(12);
    else if (type === "btn") navigator.vibrate(6);
    else if (type === "transport") navigator.vibrate([8, 30, 8]);
  }, []);

  const handlePadDown = useCallback((gridIndex, e) => {
    const soundIndex = GRID_TO_PAD[gridIndex];
    const vel = getVelocity(e, gridIndex);
    const pp = programs[padBank].params[soundIndex];
    engineRef.current?.play(soundIndex, undefined, pp, vel);
    if (seqRef.current?.recording) { seqRef.current.recordHit(soundIndex); setGridVersion(v => v + 1); }
    setActivePads(p => ({ ...p, [gridIndex]: true }));
    setPadVelocities(p => ({ ...p, [gridIndex]: vel }));
    setLastPad(soundIndex); setSelectedPad(soundIndex);
    setShowPadHit(true); setSeqViewSound(soundIndex);
    haptic("pad");
  }, [padBank, programs, getVelocity, haptic]);

  const handlePadUp = useCallback((gridIndex) => {
    setActivePads(p => { const n = { ...p }; delete n[gridIndex]; return n; });
    setPadVelocities(p => { const n = { ...p }; delete n[gridIndex]; return n; });
    setTimeout(() => setShowPadHit(false), 800);
  }, []);

  /* ── Transport ── */
  const handlePlay = useCallback(() => { if (isPlaying) return; if (seqRef.current) { seqRef.current.recording = false; seqRef.current.overdub = false; seqRef.current.start(false); } setIsPlaying(true); setIsRecording(false); setIsOverdub(false); haptic("transport"); }, [isPlaying, haptic]);
  const handlePlayStart = useCallback(() => { if (seqRef.current) { seqRef.current.recording = false; seqRef.current.overdub = false; seqRef.current.start(true); } setIsPlaying(true); setIsRecording(false); setIsOverdub(false); haptic("transport"); }, [haptic]);
  const handleStop = useCallback(() => { seqRef.current?.stop(); setIsPlaying(false); setIsRecording(false); setIsOverdub(false); setCurrentStep(-1); haptic("transport"); }, [haptic]);
  const handleRec = useCallback(() => { if (isRecording && !isOverdub) { handleStop(); return; } seqRef.current?.startRecord(); setIsPlaying(true); setIsRecording(true); setIsOverdub(false); haptic("transport"); }, [isRecording, isOverdub, handleStop, haptic]);
  const handleOverdub = useCallback(() => { if (isOverdub) { if (seqRef.current) { seqRef.current.recording = false; seqRef.current.overdub = false; } setIsRecording(false); setIsOverdub(false); return; } seqRef.current?.startOverdub(); setIsPlaying(true); setIsRecording(true); setIsOverdub(true); haptic("transport"); }, [isOverdub, haptic]);
  const handleErase = useCallback(() => { seqRef.current?.clearAll(); setPrograms(prev => { const n = { ...prev }; n[padBank] = { ...n[padBank], grid: Array.from({ length: 16 }, () => new Set()) }; return n; }); setGridVersion(v => v + 1); }, [padBank]);

  /* ── Param editing ── */
  const updatePadParam = useCallback((key, value) => {
    const pk = key.replace("p_", "");
    setPrograms(prev => { const n = { ...prev }; const b = { ...n[padBank] }; const ps = [...b.params]; ps[selectedPad] = { ...ps[selectedPad], [pk]: value }; b.params = ps; n[padBank] = b; return n; });
  }, [padBank, selectedPad]);

  const adjustValue = useCallback((delta) => {
    const screen = SCREENS[currentScreen]; if (!screen) return;
    const field = screen.fields[cursorRow]; if (!field) return;
    if (screen.isProgram) {
      const pk = field.key.replace("p_", "");
      const cur = programs[padBank].params[selectedPad][pk];
      const next = Math.max(field.min, Math.min(field.max, cur + delta));
      updatePadParam(field.key, next);
      setData(d => ({ ...d, [field.key]: next }));
      return;
    }
    setData(prev => {
      const val = prev[field.key];
      if (field.type === "number") return { ...prev, [field.key]: Math.max(field.min, Math.min(field.max, (val || 0) + delta)) };
      if (field.type === "decimal") { const s = field.step || 0.1; return { ...prev, [field.key]: Math.max(field.min, Math.min(field.max, parseFloat(((val || 0) + delta * s).toFixed(1)))) }; }
      if (field.type === "list") { const o = field.options; return { ...prev, [field.key]: o[(o.indexOf(val) + delta + o.length) % o.length] }; }
      return prev;
    });
  }, [currentScreen, cursorRow, padBank, selectedPad, programs, updatePadParam]);

  const onWheelPointerDown = (e) => {
    wheelStartY.current = e.clientY; wheelStartVal.current = 0;
    const onMove = (ev) => { const s = Math.round((wheelStartY.current - ev.clientY) / 12); if (s !== wheelStartVal.current) { adjustValue(s - wheelStartVal.current); wheelStartVal.current = s; } };
    const onUp = () => { window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp); };
    window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
  };

  const moveCursor = (dir) => {
    const screen = SCREENS[currentScreen]; if (!screen) return;
    if (dir === "UP") setCursorRow(r => Math.max(0, r - 1));
    if (dir === "DOWN") setCursorRow(r => Math.min(screen.fields.length - 1, r + 1));
    if (dir === "LEFT") adjustValue(-1); if (dir === "RIGHT") adjustValue(1);
  };

  const handleFKey = (index) => {
    const screen = SCREENS[currentScreen]; if (!screen) return;
    const label = screen.fKeys[index];
    const sm = { "MAIN": "MAIN", "SEQ": "SEQ", "TRIM": "TRIM", "PROG": "PROG", "EFFECT": "EFFECT", "MIDI/SY": "MIDI" };
    if (sm[label]) { setCurrentScreen(sm[label]); setCursorRow(0); }
    if (label === "CLEAR") handleErase();
    if (label === "RESET") { ["p_volume","p_pan","p_tune","p_decay"].forEach((k,i) => updatePadParam(k, [80,0,0,50][i])); setData(d => ({ ...d, p_volume: 80, p_pan: 0, p_tune: 0, p_decay: 50 })); }
    if (label === "COPY" && screen.isProgram) setClipboard({ ...programs[padBank].params[selectedPad] });
    if (label === "PASTE" && screen.isProgram && clipboard) { Object.entries(clipboard).forEach(([k, v]) => updatePadParam("p_" + k, v)); setData(d => ({ ...d, p_volume: clipboard.volume, p_pan: clipboard.pan, p_tune: clipboard.tune, p_decay: clipboard.decay })); }
    if (label === "INIT") setPrograms(prev => { const n = { ...prev }; n[padBank] = { ...n[padBank], params: defaultPP() }; return n; });
    haptic("btn");
  };

  const switchBank = (bank) => { if (isPlaying) handleStop(); setPadBank(bank); haptic("btn"); };
  const handleBtnDown = (id) => { setActiveBtn(id); if (["UP","DOWN","LEFT","RIGHT"].includes(id)) moveCursor(id); if (id === "MAIN") { setCurrentScreen("MAIN"); setCursorRow(0); } haptic("btn"); };
  const handleBtnUp = () => setActiveBtn(null);

  const screen = SCREENS[currentScreen];
  const formatVal = (field, val) => {
    if (field.type === "decimal") return val.toFixed(1);
    if (field.type === "number" && field.pad) return String(val).padStart(field.pad, "0");
    if (field.key === "p_pan") return val === 0 ? "C" : val > 0 ? `R${val}` : `L${Math.abs(val)}`;
    if (field.key === "p_tune") return val === 0 ? "0" : val > 0 ? `+${val}` : `${val}`;
    if (field.key === "swing") return `${val}%`;
    return String(val);
  };

  const seq = seqRef.current;
  const totalSteps = (seq?.totalSteps) || 32;
  const handleStepToggle = (step) => { seq?.toggleStep(seqViewSound, step); setGridVersion(v => v + 1); };
  const cycleSeqSound = (dir) => setSeqViewSound(s => (s + dir + 16) % 16);

  /* ── Responsive scale ── */
  const containerRef = useRef(null);
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const measure = () => {
      if (!containerRef.current) return;
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      const targetH = 860;
      const targetW = 480;
      const s = Math.min(vh / targetH, vw / targetW, 1);
      setScale(s);
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  return (
    <div style={ST.wrapper}>
      <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Outfit:wght@300;500;700;900&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet" />
      <div ref={containerRef} style={{ ...ST.body, transform: `scale(${scale})`, transformOrigin: "top center" }}>
        {!booted && <BootScreen onComplete={() => setBooted(true)} />}

        {/* Branding */}
        <div style={ST.brandBar}>
          <div style={ST.brandLeft}>
            <span style={ST.brandName}>BeatAssassin</span>
            <span style={ST.brandSub}>AFG8500</span>
          </div>
          <div style={ST.brandRight}>
            <div style={{ ...ST.brandDot, background: isPlaying ? "#4aea4a" : "#ccc", boxShadow: isPlaying ? "0 0 6px #4aea4a" : "none" }} />
            <div style={{ ...ST.brandDot, background: isRecording ? "#ff3333" : "#e8a040", boxShadow: isRecording ? "0 0 6px #ff3333" : "none" }} />
            <div style={{ ...ST.brandDot, background: isOverdub ? "#ffaa00" : "#444", boxShadow: isOverdub ? "0 0 6px #ffaa00" : "none" }} />
          </div>
        </div>

        {/* Controls */}
        <div style={ST.controlsSection}>
          <div style={ST.controlsRow}>
            <div style={ST.lcdBezel}>
              <div style={ST.lcdScreen}>
                <div style={ST.lcdTitleBar}>
                  <span style={ST.lcdTitle}>{screen.title}</span>
                  <span style={ST.lcdStatus}>{isRecording ? "● REC" : isPlaying ? "▶ PLAY" : "■ STOP"} BNK:{padBank}</span>
                </div>

                {screen.isSequencer ? (
                  <div style={ST.seqView}>
                    <div style={ST.seqSoundRow}>
                      <span style={ST.seqArrow} onPointerDown={() => cycleSeqSound(-1)}>◂</span>
                      <span style={ST.seqSoundLabel}>{SOUND_NAMES[seqViewSound]}</span>
                      <span style={ST.seqArrow} onPointerDown={() => cycleSeqSound(1)}>▸</span>
                    </div>
                    <div style={ST.stepGridWrap}>
                      {Array.from({ length: totalSteps }).map((_, step) => {
                        const isOn = seq?.grid[seqViewSound]?.has(step);
                        const isCur = step === currentStep;
                        const isBeat = step % 4 === 0;
                        return <div key={step} style={{
                          ...ST.stepCell,
                          background: isOn ? (isCur ? "#ffc040" : "#e88520") : (isCur ? "rgba(255,160,40,0.25)" : isBeat ? "rgba(255,160,40,0.08)" : "rgba(255,160,40,0.03)"),
                          border: isCur ? "1px solid #ffa830" : "1px solid rgba(255,160,40,0.1)",
                        }} onPointerDown={() => handleStepToggle(step)} />;
                      })}
                    </div>
                    <div style={ST.beatNumbers}>
                      {Array.from({ length: data.bars * 4 }).map((_, i) => <span key={i} style={ST.beatNum}>{Math.floor(i / 4) + 1}.{(i % 4) + 1}</span>)}
                    </div>
                    {screen.fields.map((field, i) => {
                      const isSel = i === cursorRow;
                      return <div key={field.key} style={{ ...ST.lcdFieldRow, background: isSel ? "rgba(255,180,60,0.15)" : "transparent" }}>
                        <span style={ST.lcdFieldLabel}>{field.label}</span>
                        <span style={{ ...ST.lcdFieldValue, color: isSel ? "#ffe0a0" : "#d4944a", fontWeight: isSel ? 700 : 400 }}>{isSel ? "▸" : " "}{formatVal(field, data[field.key])}</span>
                      </div>;
                    })}
                  </div>
                ) : screen.isProgram ? (
                  <div style={ST.progView}>
                    <div style={ST.progHeader}>
                      <span style={ST.progPadName}>Pad {selectedPad + 1}: {SOUND_NAMES[selectedPad]}</span>
                      <span style={ST.progKitName}>{programs[padBank].name}</span>
                    </div>
                    <div style={ST.paramMeters}>
                      {screen.fields.map((field, i) => {
                        const val = data[field.key]; const isSel = i === cursorRow;
                        const pct = field.key === "p_pan" ? (val + 50) : field.key === "p_tune" ? ((val + 12) / 24) * 100 : val;
                        return <div key={field.key} style={{ ...ST.meterRow, background: isSel ? "rgba(255,180,60,0.12)" : "transparent" }}>
                          <span style={{ ...ST.meterLabel, color: isSel ? "#ffe0a0" : "#9a6830" }}>{field.label}</span>
                          <div style={ST.meterTrack}><div style={{ ...ST.meterFill, width: `${Math.max(2, pct)}%`, background: isSel ? "#ffa830" : "#9a6830" }} /></div>
                          <span style={{ ...ST.meterVal, color: isSel ? "#ffe0a0" : "#d4944a" }}>{formatVal(field, val)}</span>
                        </div>;
                      })}
                    </div>
                    <div style={ST.progHint}>Tap pad to select · ▲▼ + dial to edit</div>
                  </div>
                ) : (
                  <>
                    <div style={ST.lcdFields}>
                      {screen.fields.map((field, i) => {
                        const isSel = i === cursorRow;
                        return <div key={field.key} style={{ ...ST.lcdFieldRow, background: isSel ? "rgba(255,180,60,0.15)" : "transparent" }}>
                          <span style={ST.lcdFieldLabel}>{field.label}</span>
                          <span style={{ ...ST.lcdFieldValue, color: isSel ? "#ffe0a0" : "#d4944a", fontWeight: isSel ? 700 : 400, textShadow: isSel ? "0 0 8px rgba(255,160,40,0.5)" : "none" }}>
                            {isSel ? "▸" : " "}{formatVal(field, data[field.key])}{field.type === "list" && isSel && " ◂"}
                          </span>
                        </div>;
                      })}
                    </div>
                    {currentScreen === "MAIN" && isPlaying && (
                      <div style={ST.posBar}>
                        <div style={ST.posTrack}><div style={{ ...ST.posHead, left: `${(currentStep / totalSteps) * 100}%` }} /></div>
                        <span style={ST.posText}>{Math.floor(currentStep / 16) + 1}.{Math.floor((currentStep % 16) / 4) + 1}.{String(currentStep % 4).padStart(2, "0")}</span>
                      </div>
                    )}
                  </>
                )}
                {showPadHit && lastPad !== null && !screen.isSequencer && !screen.isProgram && <div style={ST.lcdPadHitBar}>● {SOUND_NAMES[lastPad]}</div>}
                <div style={ST.lcdMenuRow}>
                  {screen.fKeys.map((label, i) => <span key={i} style={ST.lcdMenuItem} onPointerDown={() => handleFKey(i)}>{label}</span>)}
                </div>
              </div>
            </div>
            <div style={ST.controlCluster}>
              <div style={ST.dataWheelWrap}>
                <div style={ST.dataWheel} onPointerDown={onWheelPointerDown}>
                  <div style={ST.dataWheelInner}>
                    <div style={ST.dataWheelNotch} />
                    {[0,1,2,3,4,5,6,7,8,9,10,11].map(i => <div key={i} style={{ ...ST.dataWheelTick, transform: `rotate(${i*30}deg) translateY(-18px)` }} />)}
                  </div>
                </div>
                <span style={ST.dataLabel}>DATA ↕</span>
              </div>
              <div style={ST.cursorCluster}>
                {[[null,"UP",null],["LEFT",null,"RIGHT"],[null,"DOWN",null]].map((row,ri) => (
                  <div key={ri} style={ST.cursorRow}>
                    {row.map((dir,ci) => dir ? (
                      <button key={dir} style={{ ...ST.cursorBtn, ...(activeBtn === dir ? ST.cursorBtnActive : {}) }}
                        onPointerDown={() => handleBtnDown(dir)} onPointerUp={handleBtnUp} onPointerLeave={handleBtnUp}>
                        {dir === "UP" ? "▲" : dir === "DOWN" ? "▼" : dir === "LEFT" ? "◀" : "▶"}
                      </button>
                    ) : <div key={ci} style={ST.cursorSpacer} />)}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div style={ST.fRow}>
            {["F1","F2","F3","F4","F5","F6"].map((fk, i) => (
              <button key={fk} style={{ ...ST.fKey, ...(activeBtn === fk ? ST.fKeyActive : {}) }}
                onPointerDown={() => { handleBtnDown(fk); handleFKey(i); }} onPointerUp={handleBtnUp} onPointerLeave={handleBtnUp}>{fk}</button>
            ))}
          </div>

          <div style={ST.midRow}>
            <div style={ST.screenTabs}>
              {SCREEN_ORDER.map(s => (
                <button key={s} style={{ ...ST.screenTab, ...(currentScreen === s ? ST.screenTabActive : {}) }}
                  onPointerDown={() => { setCurrentScreen(s); setCursorRow(0); }}>{s === "EFFECT" ? "FX" : s.slice(0, 4)}</button>
              ))}
            </div>
            <div style={ST.transportRow}>
              {[
                { id: "PLAY", sym: "▶", col: "#4a9a4a", act: isPlaying && !isRecording, fn: handlePlay },
                { id: "PSTART", sym: "⏮", col: "#4a9a4a", act: false, fn: handlePlayStart },
                { id: "STOP", sym: "■", col: "#9a4a4a", act: !isPlaying, fn: handleStop },
                { id: "REC", sym: "●", col: "#cc3333", act: isRecording && !isOverdub, fn: handleRec },
                { id: "ODUB", sym: "⊕", col: "#c89030", act: isOverdub, fn: handleOverdub },
              ].map(b => (
                <button key={b.id} style={{ ...ST.transportBtn, ...(activeBtn === b.id ? ST.transportBtnActive : {}), ...(b.act ? ST.transportBtnLit : {}) }}
                  onPointerDown={() => { setActiveBtn(b.id); b.fn(); }} onPointerUp={handleBtnUp} onPointerLeave={handleBtnUp}>
                  <span style={{ color: b.col, fontSize: 12, lineHeight: 1 }}>{b.sym}</span>
                </button>
              ))}
            </div>
          </div>

          <div style={ST.utilRow}>
            <div style={ST.padBankRow}>
              {["A","B","C","D"].map(b => (
                <button key={b} style={{ ...ST.padBankBtn, ...(padBank === b ? ST.padBankBtnActive : {}) }} onPointerDown={() => switchBank(b)}>
                  <span>{b}</span><span style={ST.bankKitName}>{PRESET_KITS[b].name.slice(0, 3)}</span>
                </button>
              ))}
              <span style={ST.padBankLabel}>BANK</span>
            </div>
            <div style={ST.utilBtns}>
              {[{ l: "MAIN", fn: () => { setCurrentScreen("MAIN"); setCursorRow(0); } }, { l: "TAP", fn: () => {} }, { l: "ERASE", fn: handleErase }].map(b => (
                <button key={b.l} style={{ ...ST.utilBtn, ...(activeBtn === b.l ? ST.utilBtnActive : {}) }}
                  onPointerDown={() => { handleBtnDown(b.l); b.fn(); }} onPointerUp={handleBtnUp} onPointerLeave={handleBtnUp}>{b.l}</button>
              ))}
            </div>
          </div>
        </div>

        {/* PAD GRID */}
        <div style={ST.padSection}>
          <div style={ST.padGrid}>
            {PAD_LABELS.map((label, gridIdx) => {
              const soundIdx = GRID_TO_PAD[gridIdx];
              const isActive = activePads[gridIdx];
              const vel = padVelocities[gridIdx] || 1;
              const glow = PAD_GLOW[soundIdx];
              const hasSteps = seq?.grid[soundIdx]?.size > 0;
              const isSel = selectedPad === soundIdx && currentScreen === "PROG";
              const pp = programs[padBank].params[soundIdx];
              const volOpacity = 0.35 + (pp.volume / 100) * 0.65;
              const glowIntensity = Math.round(vel * 80);
              return (
                <button key={gridIdx} style={{
                  ...ST.pad,
                  background: isActive
                    ? `radial-gradient(circle at 40% 35%, ${glow}${Math.round(vel * 99).toString(16).padStart(2, "0")}, ${glow}22 60%, #33333a)`
                    : "radial-gradient(circle at 40% 35%, #55555e, #3a3a42 60%, #2e2e36)",
                  boxShadow: isActive
                    ? `0 0 ${glowIntensity}px ${glow}44, 0 0 ${glowIntensity / 3}px ${glow}22, inset 0 2px 8px rgba(0,0,0,0.3)`
                    : isSel ? `0 0 12px ${glow}33, 0 4px 10px rgba(0,0,0,0.25)` : "0 4px 10px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.06), inset 0 -2px 0 rgba(0,0,0,0.2)",
                  transform: isActive ? `scale(${0.9 + (1 - vel) * 0.06})` : "scale(1)",
                  borderColor: isActive ? glow + "66" : isSel ? glow + "55" : hasSteps ? glow + "33" : "rgba(255,255,255,0.06)",
                  opacity: volOpacity,
                }}
                  onPointerDown={e => { e.preventDefault(); handlePadDown(gridIdx, e); }}
                  onPointerUp={() => handlePadUp(gridIdx)}
                  onPointerLeave={() => handlePadUp(gridIdx)}>
                  <span style={ST.padSoundName}>{SOUND_NAMES[soundIdx]}</span>
                  <span style={ST.padLabel}>{label}</span>
                  {hasSteps && <div style={{ ...ST.padIndicator, background: glow }} />}
                  {pp.tune !== 0 && <div style={ST.padTuneBadge}>{pp.tune > 0 ? "+" : ""}{pp.tune}</div>}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   STYLES
   ═══════════════════════════════════════════ */
const ST = {
  wrapper: {
    width: "100vw", height: "100vh", display: "flex", alignItems: "flex-start", justifyContent: "center",
    background: "#e8e4e0", overflow: "hidden", touchAction: "manipulation",
    userSelect: "none", WebkitUserSelect: "none", WebkitTouchCallout: "none",
    paddingTop: "env(safe-area-inset-top, 0px)",
  },
  body: {
    width: 480, height: 860,
    background: "linear-gradient(175deg, #f5f3f0 0%, #edeae6 30%, #e8e5e0 60%, #e2dfda 100%)",
    borderRadius: 20, display: "flex", flexDirection: "column", padding: "10px 14px", boxSizing: "border-box",
    boxShadow: "0 1px 0 #fff inset, 0 12px 40px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.04)",
    overflow: "hidden", fontFamily: "'DM Sans', sans-serif", position: "relative",
  },
  brandBar: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "2px 4px 6px" },
  brandLeft: { display: "flex", flexDirection: "column" },
  brandName: { fontFamily: "'Outfit', sans-serif", fontWeight: 900, fontSize: 19, color: "#2a2a2a", letterSpacing: -0.5, lineHeight: 1 },
  brandSub: { fontFamily: "'Outfit', sans-serif", fontWeight: 300, fontSize: 10, color: "#b0a89e", letterSpacing: 5, marginTop: 1 },
  brandRight: { display: "flex", gap: 5, alignItems: "center" },
  brandDot: { width: 7, height: 7, borderRadius: "50%", transition: "all 0.2s" },

  controlsSection: { display: "flex", flexDirection: "column", gap: 4 },
  controlsRow: { display: "flex", gap: 8 },

  lcdBezel: { flex: 1, background: "#1c1810", borderRadius: 8, padding: 3, boxShadow: "inset 0 2px 8px rgba(0,0,0,0.7), 0 1px 0 rgba(255,255,255,0.3)" },
  lcdScreen: {
    background: "linear-gradient(180deg, #4a2800 0%, #3a1e00 50%, #2e1800 100%)", borderRadius: 5, padding: "4px 6px",
    minHeight: 100, display: "flex", flexDirection: "column", gap: 1, boxShadow: "inset 0 0 30px rgba(200,120,0,0.08)",
  },
  lcdTitleBar: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 1, paddingBottom: 2, borderBottom: "1px solid rgba(255,160,40,0.15)" },
  lcdTitle: { fontFamily: "'Share Tech Mono', monospace", fontSize: 11, color: "#ffa830", textShadow: "0 0 8px rgba(255,160,40,0.5)", fontWeight: 700 },
  lcdStatus: { fontFamily: "'Share Tech Mono', monospace", fontSize: 7, color: "#9a6830" },
  lcdPadHitBar: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#ffc060", textAlign: "right", marginTop: 1 },
  lcdFields: { flex: 1, display: "flex", flexDirection: "column", gap: 1 },
  lcdFieldRow: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "1px 3px", borderRadius: 2 },
  lcdFieldLabel: { fontFamily: "'Share Tech Mono', monospace", fontSize: 9, color: "#9a6830" },
  lcdFieldValue: { fontFamily: "'Share Tech Mono', monospace", fontSize: 9, color: "#d4944a" },
  lcdMenuRow: { display: "flex", justifyContent: "space-between", marginTop: 2, borderTop: "1px solid rgba(255,160,40,0.12)", paddingTop: 2 },
  lcdMenuItem: { fontFamily: "'Share Tech Mono', monospace", fontSize: 7, color: "#9a6830", cursor: "pointer", padding: "1px 2px" },

  seqView: { flex: 1, display: "flex", flexDirection: "column", gap: 2 },
  seqSoundRow: { display: "flex", alignItems: "center", justifyContent: "center", gap: 8 },
  seqSoundLabel: { fontFamily: "'Share Tech Mono', monospace", fontSize: 10, color: "#ffa830", fontWeight: 700, minWidth: 60, textAlign: "center" },
  seqArrow: { fontFamily: "'Share Tech Mono', monospace", fontSize: 12, color: "#d4944a", cursor: "pointer", padding: "0 4px" },
  stepGridWrap: { display: "flex", flexWrap: "wrap", gap: 2, padding: "2px 0" },
  stepCell: { width: "calc(6.25% - 2px)", aspectRatio: "1", borderRadius: 2, cursor: "pointer", transition: "background 0.05s", flexShrink: 0, minWidth: 0, boxSizing: "border-box" },
  beatNumbers: { display: "flex", justifyContent: "space-around" },
  beatNum: { fontFamily: "'Share Tech Mono', monospace", fontSize: 6, color: "#7a5828" },

  progView: { flex: 1, display: "flex", flexDirection: "column", gap: 2 },
  progHeader: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  progPadName: { fontFamily: "'Share Tech Mono', monospace", fontSize: 10, color: "#ffa830", fontWeight: 700 },
  progKitName: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#7a5828", letterSpacing: 1 },
  paramMeters: { display: "flex", flexDirection: "column", gap: 3, flex: 1 },
  meterRow: { display: "flex", alignItems: "center", gap: 4, padding: "2px 3px", borderRadius: 2 },
  meterLabel: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#9a6830", width: 38, flexShrink: 0 },
  meterTrack: { flex: 1, height: 5, background: "rgba(255,160,40,0.08)", borderRadius: 3, overflow: "hidden" },
  meterFill: { height: "100%", borderRadius: 3, transition: "width 0.08s" },
  meterVal: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#d4944a", width: 28, textAlign: "right", flexShrink: 0 },
  progHint: { fontFamily: "'Share Tech Mono', monospace", fontSize: 6, color: "#5a3818", textAlign: "center" },

  posBar: { display: "flex", alignItems: "center", gap: 6, marginTop: 2 },
  posTrack: { flex: 1, height: 4, background: "rgba(255,160,40,0.1)", borderRadius: 2, position: "relative" },
  posHead: { position: "absolute", top: -1, width: 6, height: 6, borderRadius: "50%", background: "#ffa830", boxShadow: "0 0 6px rgba(255,160,40,0.5)", transition: "left 0.05s" },
  posText: { fontFamily: "'Share Tech Mono', monospace", fontSize: 8, color: "#d4944a", minWidth: 36 },

  controlCluster: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4, width: 86 },
  dataWheelWrap: { display: "flex", flexDirection: "column", alignItems: "center", gap: 2 },
  dataWheel: {
    width: 50, height: 50, borderRadius: "50%",
    background: "conic-gradient(from 0deg, #d4d0cc, #eae6e2, #d4d0cc, #eae6e2, #d4d0cc, #eae6e2, #d4d0cc, #eae6e2, #d4d0cc)",
    boxShadow: "0 2px 8px rgba(0,0,0,0.12), inset 0 0 0 2px rgba(255,255,255,0.5), 0 0 0 1px rgba(0,0,0,0.08)",
    display: "flex", alignItems: "center", justifyContent: "center", cursor: "ns-resize",
  },
  dataWheelInner: {
    width: 36, height: 36, borderRadius: "50%",
    background: "radial-gradient(circle at 40% 35%, #f0ece8, #d8d4d0 70%)",
    boxShadow: "inset 0 2px 6px rgba(0,0,0,0.1), 0 1px 0 rgba(255,255,255,0.6)", position: "relative",
  },
  dataWheelNotch: { position: "absolute", top: 4, left: "50%", transform: "translateX(-50%)", width: 3, height: 8, background: "#e8a040", borderRadius: 2 },
  dataWheelTick: { position: "absolute", top: "50%", left: "50%", width: 1, height: 3, background: "rgba(0,0,0,0.1)", transformOrigin: "center center" },
  dataLabel: { fontSize: 7, color: "#a09888", fontFamily: "'Share Tech Mono', monospace", letterSpacing: 1 },

  cursorCluster: { display: "flex", flexDirection: "column", alignItems: "center", gap: 1 },
  cursorRow: { display: "flex", gap: 1, justifyContent: "center" },
  cursorBtn: {
    width: 26, height: 21, borderRadius: 5,
    background: "linear-gradient(180deg, #e8e4e0 0%, #d8d4d0 100%)",
    border: "1px solid rgba(0,0,0,0.08)", color: "#888", fontSize: 8, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    boxShadow: "0 2px 4px rgba(0,0,0,0.06), inset 0 1px 0 #fff", transition: "transform 0.05s",
  },
  cursorBtnActive: { background: "linear-gradient(180deg, #d0ccc8 0%, #c8c4c0 100%)", boxShadow: "inset 0 2px 4px rgba(0,0,0,0.1)", transform: "scale(0.93)" },
  cursorSpacer: { width: 26, height: 21 },

  fRow: { display: "flex", gap: 3 },
  fKey: {
    flex: 1, height: 20, borderRadius: 5,
    background: "linear-gradient(180deg, #e8e4e0 0%, #ddd9d5 100%)",
    border: "1px solid rgba(0,0,0,0.06)", color: "#777",
    fontFamily: "'DM Sans', sans-serif", fontSize: 9, fontWeight: 700,
    cursor: "pointer", boxShadow: "0 2px 4px rgba(0,0,0,0.05), inset 0 1px 0 #fff", transition: "transform 0.05s",
  },
  fKeyActive: { background: "linear-gradient(180deg, #d8d4d0 0%, #ccc8c4 100%)", boxShadow: "inset 0 2px 4px rgba(0,0,0,0.1)", transform: "scale(0.96)" },

  midRow: { display: "flex", gap: 5, alignItems: "center" },
  screenTabs: { display: "flex", gap: 2, flex: 1 },
  screenTab: {
    flex: 1, height: 17, borderRadius: 4,
    background: "linear-gradient(180deg, #e4e0dc 0%, #d8d4d0 100%)",
    border: "1px solid rgba(0,0,0,0.05)", color: "#aaa",
    fontFamily: "'Share Tech Mono', monospace", fontSize: 7,
    cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.1s",
  },
  screenTabActive: { background: "linear-gradient(180deg, #4a2800 0%, #3a1e00 100%)", color: "#ffa830", border: "1px solid #5a3800", boxShadow: "0 0 8px rgba(255,160,40,0.2)" },
  transportRow: { display: "flex", gap: 3 },
  transportBtn: {
    width: 28, height: 24, borderRadius: 6,
    background: "linear-gradient(180deg, #e8e4e0 0%, #d8d4d0 100%)",
    border: "1px solid rgba(0,0,0,0.06)", cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    boxShadow: "0 2px 4px rgba(0,0,0,0.06), inset 0 1px 0 #fff", transition: "all 0.08s",
  },
  transportBtnActive: { background: "linear-gradient(180deg, #d0ccc8 0%, #c8c4c0 100%)", boxShadow: "inset 0 2px 4px rgba(0,0,0,0.1)", transform: "scale(0.93)" },
  transportBtnLit: { boxShadow: "0 0 8px rgba(255,160,40,0.2), 0 2px 4px rgba(0,0,0,0.06), inset 0 1px 0 #fff", border: "1px solid rgba(255,160,40,0.3)" },

  utilRow: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  padBankRow: { display: "flex", gap: 3, alignItems: "center" },
  padBankBtn: {
    width: 32, height: 18, borderRadius: 4,
    background: "linear-gradient(180deg, #e4e0dc 0%, #d8d4d0 100%)",
    border: "1px solid rgba(0,0,0,0.06)", color: "#999",
    fontFamily: "'DM Sans', sans-serif", fontSize: 8, fontWeight: 700,
    cursor: "pointer", boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", lineHeight: 1, gap: 0, padding: 0,
  },
  padBankBtnActive: { background: "linear-gradient(180deg, #4a2800 0%, #3a1e00 100%)", color: "#ffa830", border: "1px solid #5a3800", boxShadow: "0 0 6px rgba(255,160,40,0.2)" },
  bankKitName: { fontSize: 5, opacity: 0.7, letterSpacing: 0.5 },
  padBankLabel: { fontSize: 8, color: "#b0a89e", fontWeight: 600, marginLeft: 3, letterSpacing: 2 },
  utilBtns: { display: "flex", gap: 3 },
  utilBtn: {
    height: 17, padding: "0 7px", borderRadius: 4,
    background: "linear-gradient(180deg, #e4e0dc 0%, #d8d4d0 100%)",
    border: "1px solid rgba(0,0,0,0.06)", color: "#999",
    fontFamily: "'DM Sans', sans-serif", fontSize: 7, fontWeight: 700,
    cursor: "pointer", boxShadow: "0 1px 3px rgba(0,0,0,0.05)", letterSpacing: 1,
  },
  utilBtnActive: { background: "linear-gradient(180deg, #d0ccc8 0%, #c8c4c0 100%)", boxShadow: "inset 0 2px 3px rgba(0,0,0,0.08)", transform: "scale(0.95)" },

  padSection: {
    flex: 1, marginTop: 6, minHeight: 0,
    background: "linear-gradient(180deg, rgba(0,0,0,0.02) 0%, rgba(0,0,0,0.04) 100%)",
    borderRadius: 14, padding: 6, boxShadow: "inset 0 1px 4px rgba(0,0,0,0.04)",
  },
  padGrid: { width: "100%", height: "100%", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gridTemplateRows: "repeat(4, 1fr)", gap: 8 },
  pad: {
    borderRadius: 14, border: "1px solid rgba(255,255,255,0.06)", cursor: "pointer",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    gap: 2, padding: 4, transition: "transform 0.04s, box-shadow 0.06s, opacity 0.15s",
    position: "relative", minHeight: 0,
  },
  padSoundName: { fontSize: 8, color: "rgba(255,255,255,0.45)", fontFamily: "'Share Tech Mono', monospace", fontWeight: 500, lineHeight: 1, textAlign: "center", letterSpacing: 0.5 },
  padLabel: { fontSize: 11, color: "rgba(255,255,255,0.2)", fontFamily: "'Outfit', sans-serif", fontWeight: 700, lineHeight: 1 },
  padIndicator: { position: "absolute", top: 5, right: 5, width: 4, height: 4, borderRadius: "50%", opacity: 0.6 },
  padTuneBadge: { position: "absolute", top: 4, left: 4, fontFamily: "'Share Tech Mono', monospace", fontSize: 6, color: "rgba(255,255,255,0.35)", lineHeight: 1 },
};
